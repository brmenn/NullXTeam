@protobufjs/inquire
===================
[![npm](https://img.shields.io/npm/v/@protobufjs/inquire.svg)](https://www.npmjs.com/package/@protobufjs/inquire)

Requires a module only if available and hides the require call from bundlers.

API
---

* **inquire(moduleName: `string`): `?Object`**<br />
  Requires a module only if available.

**License:** [BSD 3-Clause License](https://opensource.org/licenses/BSD-3-Clause)
